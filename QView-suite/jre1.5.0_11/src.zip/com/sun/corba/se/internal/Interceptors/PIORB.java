/*
 * @(#)PIORB.java	1.65 04/07/27
 * 
 *
 * Copyright 2004 Sun Microsystems, Inc. All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package com.sun.corba.se.internal.Interceptors;

import com.sun.corba.se.internal.POA.POAORB;
             
/** 
 * Deprecated class for backward compatibility.
 */
public class PIORB 
    extends POAORB
{
    public PIORB() {
	super();
    }
}

// End of file.

